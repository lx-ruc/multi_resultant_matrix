import sympy as smp
from sympy import *
import numpy as np
import pandas as pd
import math
import pprint
import copy
import homogeneous
from decimal import Decimal


def matrix_with_vars(coefficients,variables,vector,parament):

    return 
